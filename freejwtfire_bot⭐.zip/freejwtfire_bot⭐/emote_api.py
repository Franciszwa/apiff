from fastapi import FastAPI
from typing import List

app = FastAPI()

@app.get("/emote")
def send_emote(region: str, tc: str, emote_id: str, uid1: str, uid2: str = None, uid3: str = None):

    uids = [uid1]

    if uid2:
        uids.append(uid2)
    if uid3:
        uids.append(uid3)

    return {
        "Developer": "Your Name",
        "region": region,
        "emote_id": emote_id,
        "message": "Emote request sent!",
        "status": "success",
        "team_code": tc,
        "uids": uids
    }